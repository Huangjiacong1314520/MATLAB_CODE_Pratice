


clear; 
clc; 
close all;
format long g;

ts = 0.0002;  
k_uf = 1/20;

%����---------
mass = 477;
num_P = [1];
den_P = [mass 0 0];
P = tf(num_P,den_P);

%����������----
num_Cfb = [179824.76349148  33696607.3425078  876981355.154548];
den_Cfb  = [0.00109873559912302  1  0];
Cfb = tf(num_Cfb,den_Cfb); 


%�Ŷ�----
global theta_true;
theta_true = [23.85 1.4 -2.4 1.9 4.3 1.0 -4.2]'*20;
n = 7;

%�ο��켣--
m_reference;

N = length(r); 
t_end = (N-1)*ts;
t = 0:ts:t_end; t = t';


%���� - ��ǰ��
simin_r = [t r];
simin_u = [t zeros(N,1)];       
simin_d = [t randn(N,1)*0.1]; 
simin_v = [t randn(N,1)*1e-9]; 
sim('Sim_singleDOF1');
err0 = r - y;

%���� - ���ٶ�ǰ��
simin_r = [t r];
uff = a*mass;
simin_u = [t uff];      
simin_d = [t randn(N,1)*0.1]; 
simin_v = [t randn(N,1)*1e-9]; 
sim('Sim_singleDOF1');
err1 = r - y;


%���� - ���ٶ�ǰ��+�Ŷ�ǰ��
simin_r = [t r];
uff1 = a*mass;

tao = 0.012;
w1 = pi/tao; 
w2 = pi/(2/3*tao);
PSI_rf = [a -sin(w1*r) -cos(w1*r) -sin(2*w1*r) -cos(2*w1*r) ...
            -sin(w2*r) -cos(w2*r)];
uff = PSI_rf*theta_true;

simin_u = [t uff];       
simin_d = [t randn(N,1)*0.1]; 
simin_v = [t randn(N,1)*1e-9]; 
sim('Sim_singleDOF1');
err2 = r - y;


figure(1);
plot(t,err0,'k','linewidth',1.2);
hold on;
plot(t,err1,'b','linewidth',1.2);
plot(t,err2,'r','linewidth',1.2);
set(figure(1),'Name', '���Ƚ�');
title('�������Ƚ�');
xlabel('ʱ�䣨s��');
ylabel('��m��');


% figure;
% subplot(211);
% plot(t,r);
% subplot(212);
% plot(t,err0,'k');
% hold on;
% plot(t,err1,'b');
% plot(t,err2,'r');


